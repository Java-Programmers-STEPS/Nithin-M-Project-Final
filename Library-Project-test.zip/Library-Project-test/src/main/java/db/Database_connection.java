package db;

public class Database_connection {
public static String driver="com.mysql.jdbc.Driver";
public static String connectionUrl="jdbc:mysql://localhost:3306/librarymanagementsystemfinal";
public static String username="root";
public static String password="";
}

